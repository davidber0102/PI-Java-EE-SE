package proceso_aplicacion;

public class iniciar_aplicacion {
	
	public static void main (String[] args) {
		desarrollo empezar= new desarrollo();
		empezar.iniciar();
		
	}

}
